import { GoogleGenAI } from "@google/genai";

const STYLE_PREFIXES = {
    'none': '',
    'photographic': 'A hyper-realistic photograph of ',
    'cinematic': 'Cinematic film still of, dramatic lighting, ',
    'anime': 'Vibrant anime style, detailed illustration of ',
    'digital-art': 'Epic digital painting of, concept art, matte painting, ',
    'fantasy': 'Epic fantasy art of, magical, otherworldly, ',
    'low-poly': 'Low-poly isometric 3D render of ',
};

class GeminiService {
  ai;

  constructor(apiKey) {
    if (!apiKey) {
      console.error("API key is missing. The app will not function correctly.");
      throw new Error("API key is not configured. Please set the API_KEY environment variable.");
    }
    this.ai = new GoogleGenAI({ apiKey });
  }

  async generateImages(options) {
    const { prompt, model, numberOfImages, aspectRatio, stylePreset } = options;
    try {
        let finalPrompt = prompt;
        if (model === 'quality') {
            const prefix = STYLE_PREFIXES[stylePreset ?? 'none'] || '';
            finalPrompt = `${prefix}${prompt}`;
        }
        
        const modelToUse = 'imagen-3.0-generate-002';

        const response = await this.ai.models.generateImages({
            model: modelToUse,
            prompt: finalPrompt,
            config: {
              numberOfImages,
              outputMimeType: 'image/jpeg',
              aspectRatio,
            },
        });

        if (!response.generatedImages || response.generatedImages.length === 0) {
            throw new Error("The API did not return any images. The prompt might be too restrictive or violate safety policies. Try a different prompt.");
        }

        return response.generatedImages.map(img => img.image.imageBytes);
    } catch (error) {
        console.error("Error generating images:", error);
        if (error instanceof Error && error.message.includes('API did not return any images')) {
            throw error;
        }
        throw new Error("Failed to generate images. An unexpected error occurred. Please check the console for more details.");
    }
  }

  async improvePrompt(prompt) {
    if (!prompt.trim()) return '';
    try {
      const response = await this.ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: `Refine this image generation prompt to be more vivid, descriptive, and imaginative. Return only the improved prompt text, without any introductory phrases like "Here's the improved prompt:":\n\n${prompt}`,
        config: { thinkingConfig: { thinkingBudget: 0 } }
      });
      return response.text.trim();
    } catch (error) {
      console.error("Error improving prompt:", error);
      throw new Error("Failed to get prompt suggestion.");
    }
  }

  async getRandomPrompt() {
    try {
        const response = await this.ai.models.generateContent({
            model: 'gemini-2.5-flash',
            contents: "Generate a single, random, highly-detailed and creative prompt for an image generation AI. Focus on a unique subject, setting, and style. Return only the prompt text.",
            config: {
                temperature: 1.2, topP: 0.98, topK: 40,
                thinkingConfig: { thinkingBudget: 0 }
            }
        });
        return response.text.trim().replace(/^"|"$/g, '');
    } catch (error) {
        console.error("Error getting random prompt:", error);
        throw new Error("Failed to get a random prompt.");
    }
  }

  async describeImage(base64, mimeType) {
    try {
      const imagePart = { inlineData: { data: base64, mimeType } };
      const textPart = { text: "Describe this image in detail. Create a rich, descriptive prompt that could be used to recreate this image with an AI image generator." };
      const response = await this.ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: { parts: [imagePart, textPart] }
      });
      return response.text;
    } catch (error) {
      console.error("Error describing image:", error);
      throw new Error("Failed to describe the image.");
    }
  }
}

export const isApiKeyMissing = !process.env.API_KEY;

let geminiService;
try {
    geminiService = new GeminiService(process.env.API_KEY);
} catch (e) {
    console.error(e);
    geminiService = {
        generateImages: () => Promise.reject(new Error("API Key not configured")),
        improvePrompt: () => Promise.reject(new Error("API Key not configured")),
        getRandomPrompt: () => Promise.reject(new Error("API Key not configured")),
        describeImage: () => Promise.reject(new Error("API Key not configured")),
    };
}
export { geminiService };
