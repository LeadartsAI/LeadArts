import { geminiService, isApiKeyMissing } from './gemini.js';
import { renderAll } from './ui.js';

// --- CONSTANTS ---
const RATE_LIMIT_COUNT = 10;
const RATE_LIMIT_WINDOW = 10 * 60 * 1000; // 10 minutes in ms

// --- DOM ELEMENTS ---
const DOMElements = {
    // Banners
    noticeBanner: document.getElementById('notice-banner'),
    dismissNoticeButton: document.getElementById('dismiss-notice-button'),
    apiKeyBanner: document.getElementById('api-key-banner'),
    // Main components
    settingsPanel: document.getElementById('settings-panel'),
    imageGalleryContainer: document.getElementById('image-gallery-container'),
    // Side Menu
    sideMenu: document.getElementById('side-menu'),
    sideMenuOverlay: document.getElementById('side-menu-overlay'),
    openMenuButton: document.getElementById('open-menu-button'),
    closeMenuButton: document.getElementById('close-menu-button'),
    historyList: document.getElementById('history-list'),
    clearHistoryButton: document.getElementById('clear-history-button'),
    // Settings: Model
    modelSelectorContainer: document.getElementById('model-selector-container'),
    // Settings: Prompt
    promptInput: document.getElementById('prompt-input'),
    improvePromptButton: document.getElementById('improve-prompt-button'),
    randomPromptButton: document.getElementById('random-prompt-button'),
    describeImageButton: document.getElementById('describe-image-button'),
    // Settings: Aspect Ratio
    aspectRatioSelector: document.getElementById('aspect-ratio-selector'),
    // Settings: Image Count
    imageCountSelector: document.getElementById('image-count-selector'),
    // Settings: Advanced
    stylePresetSelector: document.getElementById('style-preset-selector'),
    imageReferenceUploadButton: document.getElementById('image-reference-upload-button'),
    imageReferenceInput: document.getElementById('image-reference-input'),
    imageReferencePreview: document.getElementById('image-reference-preview'),
    imageReferencePlaceholder: document.getElementById('image-reference-placeholder'),
    imageReferenceRemoveButton: document.getElementById('image-reference-remove-button'),
    // Settings: Rate Limit
    rateLimitInfo: document.getElementById('rate-limit-info'),
    // Settings: Generate Button
    generateButton: document.getElementById('generate-button'),
    generateButtonText: document.getElementById('generate-button-text'),
    // Feedback form
    feedbackForm: document.getElementById('feedback-form'),
    feedbackInput: document.getElementById('feedback-input'),
    feedbackSubmit: document.getElementById('feedback-submit'),
    feedbackSuccess: document.getElementById('feedback-success'),
};

// --- APP STATE ---
let state = {
    options: {
        prompt: '',
        model: 'quality',
        aspectRatio: '1:1',
        numberOfImages: 1,
        stylePreset: 'none',
        referenceImage: null,
    },
    history: [],
    selectedHistoryId: null,
    isLoading: false,
    isPromptLoading: false,
    error: null,
    isSideMenuOpen: false,
    rateLimitInfo: null,
};
let rateLimitCountdownInterval;

// --- STATE MANAGEMENT ---
function setState(newState) {
    const oldState = { ...state };
    state = { ...state, ...newState };
    
    // Pass handlers to render functions that create dynamic elements with event listeners
    const handlers = {
        handleEditPrompt,
        handleDownloadImage,
        handleSelectHistory,
        handleDeleteHistory,
    };
    
    renderAll(state, DOMElements, handlers, isApiKeyMissing);
}

// --- EVENT HANDLERS ---
function handleOptionsChange(key, value) {
    setState({ options: { ...state.options, [key]: value } });
}

function handleSideMenuToggle(isOpen) {
    setState({ isSideMenuOpen: isOpen });
}

async function handleGenerate() {
    if (state.isLoading || !state.options.prompt.trim()) return;

    if (state.rateLimitInfo && state.options.numberOfImages > state.rateLimitInfo.remaining) {
        const errorMsg = state.rateLimitInfo.remaining === 0 
            ? 'You have reached the generation limit of 10 images per 10 minutes. Please wait for the cooldown.'
            : `You can only generate ${state.rateLimitInfo.remaining} more image(s) this period. Please reduce the number of images.`;
        setState({ error: errorMsg });
        return;
    }
    
    setState({ isLoading: true, error: null });

    try {
        const images = await geminiService.generateImages(state.options);
        const newHistoryItem = {
            id: `gen_${Date.now()}`,
            timestamp: Date.now(),
            options: { ...state.options },
            images: images,
        };
        
        const newHistory = [newHistoryItem, ...state.history];
        const now = Date.now();
        let timestamps = JSON.parse(localStorage.getItem('generationTimestamps') || '[]');
        const recentTimestamps = timestamps.filter(ts => (now - ts) < RATE_LIMIT_WINDOW);
        const newTimestamps = Array(images.length).fill(now);
        const updatedTimestamps = [...recentTimestamps, ...newTimestamps];
        localStorage.setItem('generationTimestamps', JSON.stringify(updatedTimestamps));

        checkRateLimit(updatedTimestamps);

        setState({
            history: newHistory,
            selectedHistoryId: newHistoryItem.id,
            isLoading: false
        });

        localStorage.setItem('generationHistory', JSON.stringify(newHistory));

    } catch (err) {
        setState({ error: err instanceof Error ? err.message : 'An unknown error occurred.', isLoading: false });
        console.error(err);
    }
}

function handleSelectHistory(id) {
    const selectedItem = state.history.find(item => item.id === id);
    if (selectedItem) {
        const fullOptions = {
            prompt: '', model: 'quality', aspectRatio: '1:1',
            numberOfImages: 1, referenceImage: null, stylePreset: 'none',
            ...selectedItem.options,
        };
        setState({ options: fullOptions, selectedHistoryId: id, error: null });
    }
    handleSideMenuToggle(false);
}

function handleDeleteHistory(id) {
    const newHistory = state.history.filter(item => item.id !== id);
    let newSelectedId = state.selectedHistoryId;
    if (state.selectedHistoryId === id) {
      newSelectedId = newHistory[0]?.id ?? null;
      if(!newSelectedId) {
        setState({options: {...state.options, prompt: '', referenceImage: null}});
      }
    }
    setState({ history: newHistory, selectedHistoryId: newSelectedId });
    if(newSelectedId){
        handleSelectHistory(newSelectedId)
    }
    localStorage.setItem('generationHistory', JSON.stringify(newHistory));
}

function handleClearHistory() {
    if (window.confirm("Are you sure you want to clear all history? This cannot be undone.")) {
        setState({
            history: [],
            selectedHistoryId: null,
            options: {...state.options, prompt: '', referenceImage: null},
            error: null,
        });
        localStorage.setItem('generationHistory', JSON.stringify([]));
    }
}

function handleEditPrompt(historyItem) {
    const fullOptions = {
        prompt: '', model: 'quality', aspectRatio: '1:1',
        numberOfImages: 1, referenceImage: null, stylePreset: 'none',
        ...historyItem.options,
    };
    setState({ options: fullOptions });
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

function handleDownloadImage(imageUrl, prompt) {
    const link = document.createElement('a');
    link.href = imageUrl;
    const safePrompt = prompt.substring(0, 30).replace(/[^a-z0-9]/gi, '_').toLowerCase();
    link.download = `generated_${safePrompt || 'image'}.jpg`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}

async function handlePromptAction(action) {
    setState({ isPromptLoading: true });
    try {
        let newPrompt = '';
        if (action === 'improve') {
            newPrompt = await geminiService.improvePrompt(state.options.prompt);
        } else if (action === 'random') {
            newPrompt = await geminiService.getRandomPrompt();
        } else if (action === 'describe' && state.options.referenceImage) {
            newPrompt = await geminiService.describeImage(state.options.referenceImage.base64, state.options.referenceImage.mimeType);
        }
        if (newPrompt) {
            handleOptionsChange('prompt', newPrompt);
        }
    } catch (error) {
        console.error(error);
        alert(error instanceof Error ? error.message : "An error occurred.");
    } finally {
        setState({ isPromptLoading: false });
    }
}

function checkRateLimit(currentTimestamps) {
    const now = Date.now();
    let timestamps = currentTimestamps ?? JSON.parse(localStorage.getItem('generationTimestamps') || '[]');
    
    const recentTimestamps = timestamps.filter(ts => (now - ts) < RATE_LIMIT_WINDOW);
    if (!currentTimestamps && recentTimestamps.length !== timestamps.length) {
        localStorage.setItem('generationTimestamps', JSON.stringify(recentTimestamps));
    }
    
    const remaining = RATE_LIMIT_COUNT - recentTimestamps.length;
    
    setState({
        rateLimitInfo: {
            isLimited: remaining <= 0,
            resetsAt: remaining <= 0 ? (recentTimestamps[0] || now) + RATE_LIMIT_WINDOW : null,
            limit: RATE_LIMIT_COUNT,
            remaining: Math.max(0, remaining),
        }
    });
}

// --- INITIALIZATION ---
function init() {
    // Banners
    if (localStorage.getItem('noticeDismissed') !== 'true') {
        DOMElements.noticeBanner.classList.remove('hidden');
    }
    DOMElements.dismissNoticeButton.addEventListener('click', () => {
        DOMElements.noticeBanner.classList.add('hidden');
        localStorage.setItem('noticeDismissed', 'true');
    });

    if (isApiKeyMissing) {
        DOMElements.apiKeyBanner.classList.remove('hidden');
        document.querySelectorAll('input, button, select, textarea').forEach(el => el.disabled = true);
    }

    // Load initial data
    try {
        const storedHistory = localStorage.getItem('generationHistory');
        if (storedHistory) {
            const parsedHistory = JSON.parse(storedHistory);
            const selectedId = parsedHistory[0]?.id ?? null;
            setState({ history: parsedHistory, selectedHistoryId: selectedId });
            if (selectedId) handleSelectHistory(selectedId);
        }
    } catch (e) {
        console.error("Failed to load history from localStorage", e);
        localStorage.removeItem('generationHistory');
    }

    // Set up event listeners
    DOMElements.openMenuButton.addEventListener('click', () => handleSideMenuToggle(true));
    DOMElements.closeMenuButton.addEventListener('click', () => handleSideMenuToggle(false));
    DOMElements.sideMenuOverlay.addEventListener('click', () => handleSideMenuToggle(false));
    DOMElements.clearHistoryButton.addEventListener('click', handleClearHistory);

    DOMElements.promptInput.addEventListener('input', (e) => handleOptionsChange('prompt', e.target.value));
    
    DOMElements.modelSelectorContainer.querySelectorAll('.model-button').forEach(btn => {
        btn.addEventListener('click', () => handleOptionsChange('model', btn.dataset.value));
    });

    DOMElements.aspectRatioSelector.querySelectorAll('.aspect-ratio-button').forEach(btn => {
        btn.addEventListener('click', () => handleOptionsChange('aspectRatio', btn.dataset.value));
    });

    DOMElements.imageCountSelector.querySelectorAll('.image-count-button').forEach(btn => {
        btn.addEventListener('click', () => handleOptionsChange('numberOfImages', parseInt(btn.dataset.value)));
    });

    DOMElements.stylePresetSelector.addEventListener('change', (e) => handleOptionsChange('stylePreset', e.target.value));

    DOMElements.improvePromptButton.addEventListener('click', () => handlePromptAction('improve'));
    DOMElements.randomPromptButton.addEventListener('click', () => handlePromptAction('random'));
    DOMElements.describeImageButton.addEventListener('click', () => handlePromptAction('describe'));

    DOMElements.imageReferenceUploadButton.addEventListener('click', () => DOMElements.imageReferenceInput.click());
    DOMElements.imageReferenceInput.addEventListener('change', (e) => {
        const file = e.target.files?.[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = (re) => {
                const base64 = (re.target?.result).split(',')[1];
                if (base64) handleOptionsChange('referenceImage', { base64, mimeType: file.type });
            };
            reader.readAsDataURL(file);
        }
    });
    DOMElements.imageReferenceRemoveButton.addEventListener('click', () => {
        handleOptionsChange('referenceImage', null);
        DOMElements.imageReferenceInput.value = "";
    });

    DOMElements.generateButton.addEventListener('click', handleGenerate);

    DOMElements.feedbackForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const feedback = DOMElements.feedbackInput.value;
        if (!feedback.trim()) return;
        console.log("Feedback submitted:", feedback);
        DOMElements.feedbackInput.value = '';
        DOMElements.feedbackInput.classList.add('hidden');
        DOMElements.feedbackSubmit.classList.add('hidden');
        DOMElements.feedbackSuccess.classList.remove('hidden');
        setTimeout(() => {
            DOMElements.feedbackSuccess.classList.add('hidden');
            DOMElements.feedbackInput.classList.remove('hidden');
            DOMElements.feedbackSubmit.classList.remove('hidden');
        }, 3000);
    });

    // Rate limit checking
    checkRateLimit();
    rateLimitCountdownInterval = setInterval(checkRateLimit, 1000);

    // Initial render
    setState({}); // Trigger initial render with current state
}

document.addEventListener('DOMContentLoaded', init);
