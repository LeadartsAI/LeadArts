function renderSettings(state, DOMElements) {
    DOMElements.promptInput.value = state.options.prompt;
    
    DOMElements.modelSelectorContainer.querySelectorAll('.model-button').forEach(btn => {
        const isSelected = btn.dataset.value === state.options.model;
        btn.classList.toggle('bg-indigo-600/30', isSelected);
        btn.classList.toggle('border-indigo-500', isSelected);
        btn.classList.toggle('bg-gray-700/50', !isSelected);
        btn.classList.toggle('border-gray-600', !isSelected);
        btn.querySelector('.model-badge').classList.toggle('bg-indigo-500', isSelected);
        btn.querySelector('.model-badge').classList.toggle('text-white', isSelected);
        btn.querySelector('.model-badge').classList.toggle('bg-gray-600', !isSelected);
        btn.querySelector('.model-badge').classList.toggle('text-gray-300', !isSelected);
    });

    DOMElements.aspectRatioSelector.querySelectorAll('.aspect-ratio-button').forEach(btn => {
        const isSelected = btn.dataset.value === state.options.aspectRatio;
        btn.classList.toggle('bg-indigo-600/30', isSelected);
        btn.classList.toggle('border-indigo-500', isSelected);
        btn.classList.toggle('text-white', isSelected);
        btn.classList.toggle('bg-gray-700/50', !isSelected);
        btn.classList.toggle('border-gray-600', !isSelected);
        btn.classList.toggle('hover:bg-gray-600/50', !isSelected);
        btn.classList.toggle('text-gray-400', !isSelected);
    });
    
    DOMElements.imageCountSelector.querySelectorAll('.image-count-button').forEach(btn => {
        const isSelected = parseInt(btn.dataset.value) === state.options.numberOfImages;
        btn.classList.toggle('bg-indigo-600', isSelected);
        btn.classList.toggle('text-white', isSelected);
        btn.classList.toggle('ring-2', isSelected);
        btn.classList.toggle('ring-indigo-500', isSelected);
        btn.classList.toggle('ring-offset-2', isSelected);
        btn.classList.toggle('ring-offset-gray-800', isSelected);
        btn.classList.toggle('bg-gray-700', !isSelected);
        btn.classList.toggle('hover:bg-gray-600', !isSelected);
        btn.classList.toggle('text-gray-300', !isSelected);
    });

    DOMElements.stylePresetSelector.value = state.options.stylePreset;

    if (state.options.referenceImage) {
        DOMElements.imageReferencePreview.src = `data:${state.options.referenceImage.mimeType};base64,${state.options.referenceImage.base64}`;
        DOMElements.imageReferencePreview.classList.remove('hidden');
        DOMElements.imageReferencePlaceholder.classList.add('hidden');
        DOMElements.imageReferenceRemoveButton.classList.remove('hidden');
    } else {
        DOMElements.imageReferencePreview.classList.add('hidden');
        DOMElements.imageReferencePlaceholder.classList.remove('hidden');
        DOMElements.imageReferenceRemoveButton.classList.add('hidden');
    }
}

function renderImageGallery(state, DOMElements, handlers) {
    const container = DOMElements.imageGalleryContainer;
    container.innerHTML = ''; 

    if (state.isLoading) {
        const getGridCols = (count) => {
            if (count <= 1) return 'grid-cols-1';
            if (count === 2) return 'grid-cols-1 sm:grid-cols-2';
            if (count === 3) return 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-3';
            return 'grid-cols-1 sm:grid-cols-2';
        };
        const grid = document.createElement('div');
        grid.className = `grid ${getGridCols(state.options.numberOfImages)} gap-4`;
        for (let i = 0; i < state.options.numberOfImages; i++) {
            grid.innerHTML += `
                <div class="aspect-square bg-gray-800 rounded-lg flex items-center justify-center">
                    <svg class="animate-spin -ml-1 mr-3 h-8 w-8 text-indigo-500" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg>
                </div>`;
        }
        container.appendChild(grid);
        return;
    }

    if (state.error) {
        container.innerHTML = `
            <div class="h-full flex flex-col items-center justify-center bg-gray-800/50 rounded-lg p-8 text-center">
                <svg xmlns="http://www.w3.org/2000/svg" class="w-16 h-16 text-red-500 mb-4" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M12 9v3.75m-9.303 3.376c-.866 1.5.217 3.374 1.948 3.374h14.71c1.73 0 2.813-1.874 1.948-3.374L13.949 3.378c-.866-1.5-3.032-1.5-3.898 0L2.697 16.126zM12 15.75h.007v.008H12v-.008z"></path></svg>
                <h3 class="text-xl font-bold text-white mb-2">Generation Failed</h3>
                <p class="text-gray-400 max-w-md">${state.error}</p>
            </div>`;
        return;
    }

    const generation = state.history.find(item => item.id === state.selectedHistoryId);
    if (generation && generation.images.length > 0) {
        const getGridCols = (count) => {
            if (count <= 1) return 'grid-cols-1';
            if (count === 2) return 'grid-cols-1 sm:grid-cols-2';
            if (count === 3) return 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-3';
            return 'grid-cols-1 sm:grid-cols-2';
        };
        const grid = document.createElement('div');
        grid.className = `grid ${getGridCols(generation.images.length)} gap-4`;
        
        generation.images.forEach((base64) => {
            const imageUrl = `data:image/jpeg;base64,${base64}`;
            const imageWrapper = document.createElement('div');
            imageWrapper.className = 'group relative bg-gray-800 rounded-lg overflow-hidden aspect-square';
            imageWrapper.innerHTML = `
                <img src="${imageUrl}" alt="${generation.options.prompt}" class="w-full h-full object-cover" />
                <div class="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center gap-4 p-4">
                    <button data-action="edit" class="flex items-center gap-2 bg-white/20 backdrop-blur-md text-white font-bold py-2 px-4 rounded-lg hover:bg-white/30 transition-colors">
                        <svg xmlns="http://www.w3.org/2000/svg" class="w-5 h-5" viewBox="0 0 20 20" fill="currentColor"><path d="M5.433 13.917l1.262-3.155A4 4 0 017.58 9.42l6.92-6.918a2.121 2.121 0 013 3l-6.92 6.918c-.383.383-.84.685-1.343.886l-3.154 1.262a.5.5 0 01-.65-.65z"></path><path d="M3.5 5.75c0-.69.56-1.25 1.25-1.25H10A.75.75 0 0010 3H4.75A2.75 2.75 0 002 5.75v9.5A2.75 2.75 0 004.75 18h9.5A2.75 2.75 0 0017 15.25V10a.75.75 0 00-1.5 0v5.25c0 .69-.56 1.25-1.25 1.25h-9.5c-.69 0-1.25-.56-1.25-1.25v-9.5z"></path></svg>
                        Edit Prompt
                    </button>
                    <button data-action="download" class="flex items-center gap-2 bg-white/20 backdrop-blur-md text-white font-bold py-2 px-4 rounded-lg hover:bg-white/30 transition-colors">
                        <svg xmlns="http://www.w3.org/2000/svg" class="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M3 16.5v2.25A2.25 2.25 0 005.25 21h13.5A2.25 2.25 0 0021 18.75V16.5M16.5 12L12 16.5m0 0L7.5 12m4.5 4.5V3"></path></svg>
                        Download
                    </button>
                </div>
            `;
            imageWrapper.querySelector('[data-action="edit"]').addEventListener('click', () => handlers.handleEditPrompt(generation));
            imageWrapper.querySelector('[data-action="download"]').addEventListener('click', () => handlers.handleDownloadImage(imageUrl, generation.options.prompt));
            grid.appendChild(imageWrapper);
        });
        container.appendChild(grid);
        return;
    }

    container.innerHTML = `
        <div class="h-full flex flex-col items-center justify-center bg-gray-800/50 rounded-lg p-8 text-center">
            <svg xmlns="http://www.w3.org/2000/svg" class="w-24 h-24 text-gray-600 mb-4" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M2.25 15.75l5.159-5.159a2.25 2.25 0 013.182 0l5.159 5.159m-1.5-1.5l1.409-1.409a2.25 2.25 0 013.182 0l2.909 2.909m-18 3.75h16.5a1.5 1.5 0 001.5-1.5V6a1.5 1.5 0 00-1.5-1.5H3.75A1.5 1.5 0 002.25 6v12a1.5 1.5 0 001.5 1.5zm10.5-11.25h.008v.008h-.008V8.25zm.375 0a.375.375 0 11-.75 0 .375.375 0 01.75 0z"></path></svg>
            <h3 class="text-2xl font-bold text-white">Your creations appear here</h3>
            <p class="text-gray-400 mt-2">Enter a prompt and click "Generate" to see the magic happen.</p>
        </div>`;
}

function formatTimeAgo(timestamp) {
    const seconds = Math.floor((Date.now() - timestamp) / 1000);
    if (seconds < 5) return "just now";
    if (seconds < 60) return `${seconds}s ago`;
    const minutes = Math.floor(seconds / 60);
    if (minutes < 60) return `${minutes}m ago`;
    const hours = Math.floor(minutes / 60);
    if (hours < 24) return `${hours}h ago`;
    const days = Math.floor(hours / 24);
    return `${days}d ago`;
}

function renderHistory(state, DOMElements, handlers, isApiKeyMissing) {
    const list = DOMElements.historyList;
    list.innerHTML = '';
    
    if (state.history.length === 0) {
        list.innerHTML = `
            <div class="text-center py-8 px-4">
                <p class="text-sm text-gray-500">No history yet.</p>
                <p class="text-xs text-gray-500">Your generated images will appear here.</p>
            </div>`;
        DOMElements.clearHistoryButton.disabled = true;
        return;
    }

    DOMElements.clearHistoryButton.disabled = isApiKeyMissing || state.isLoading;

    state.history.forEach(item => {
        const isSelected = item.id === state.selectedHistoryId;
        const button = document.createElement('button');
        button.className = `w-full flex items-center gap-3 p-2 rounded-lg text-left transition-colors duration-200 disabled:opacity-70 disabled:cursor-not-allowed ${isSelected ? 'bg-indigo-600/30' : 'bg-gray-700/50 hover:bg-gray-700'}`;
        button.disabled = isApiKeyMissing || state.isLoading;
        
        const thumbnail = item.images[0]
            ? `<img src="data:image/jpeg;base64,${item.images[0]}" alt="History thumbnail" class="w-full h-full object-cover rounded-md" />`
            : `<svg xmlns="http://www.w3.org/2000/svg" class="w-6 h-6 text-gray-600" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M2.25 15.75l5.159-5.159a2.25 2.25 0 013.182 0l5.159 5.159m-1.5-1.5l1.409-1.409a2.25 2.25 0 013.182 0l2.909 2.909m-18 3.75h16.5a1.5 1.5 0 001.5-1.5V6a1.5 1.5 0 00-1.5-1.5H3.75A1.5 1.5 0 002.25 6v12a1.5 1.5 0 001.5 1.5zm10.5-11.25h.008v.008h-.008V8.25zm.375 0a.375.375 0 11-.75 0 .375.375 0 01.75 0z" /></svg>`;
        
        button.innerHTML = `
            <div class="w-14 h-14 flex-shrink-0 bg-gray-900 rounded-md flex items-center justify-center">${thumbnail}</div>
            <div class="flex-grow overflow-hidden">
                <p class="text-sm font-semibold text-gray-200 truncate">${item.options.prompt || 'Untitled'}</p>
                <p class="text-xs text-gray-400">${formatTimeAgo(item.timestamp)}</p>
            </div>
            <button data-action="delete" class="p-2 text-gray-500 rounded-full hover:bg-red-800/50 hover:text-red-400 transition-colors flex-shrink-0" aria-label="Delete history item">
                <svg xmlns="http://www.w3.org/2000/svg" class="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke-width="1.5" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" d="M14.74 9l-.346 9m-4.788 0L9.26 9m9.968-3.21c.342.052.682.107 1.022.166m-1.022-.165L18.16 19.673a2.25 2.25 0 01-2.244 2.077H8.084a2.25 2.25 0 01-2.244-2.077L4.772 5.79m14.456 0a48.108 48.108 0 00-3.478-.397m-12 .562c.34-.059.68-.114 1.022-.165m0 0a48.11 48.11 0 013.478-.397m7.5 0v-.916c0-1.18-.91-2.134-2.09-2.201a51.964 51.964 0 00-3.32 0c-1.18.067-2.09 1.02-2.09 2.201v.916m7.5 0a48.667 48.667 0 00-7.5 0"></path></svg>
            </button>
        `;

        button.addEventListener('click', () => handlers.handleSelectHistory(item.id));
        const deleteButton = button.querySelector('[data-action="delete"]');
        deleteButton.addEventListener('click', (e) => {
            e.stopPropagation();
            handlers.handleDeleteHistory(item.id);
        });
        deleteButton.disabled = isApiKeyMissing || state.isLoading;

        list.appendChild(button);
    });
}

function renderSideMenu(state, DOMElements) {
    if (state.isSideMenuOpen) {
        DOMElements.sideMenu.classList.remove('-translate-x-full');
        DOMElements.sideMenuOverlay.classList.remove('opacity-0', 'pointer-events-none');
    } else {
        DOMElements.sideMenu.classList.add('-translate-x-full');
        DOMElements.sideMenuOverlay.classList.add('opacity-0', 'pointer-events-none');
    }
}

function renderRateLimit(state, DOMElements) {
    if (!state.rateLimitInfo) {
        DOMElements.rateLimitInfo.innerHTML = `<div class="h-[58px] flex items-center justify-center"><svg class="animate-spin -ml-1 mr-3 h-8 w-8 text-indigo-500" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"><circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle><path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path></svg></div>`;
        return;
    }

    if (state.rateLimitInfo.isLimited) {
        const now = Date.now();
        const diff = state.rateLimitInfo.resetsAt - now;
        const minutes = Math.floor(diff / 60000).toString().padStart(2, '0');
        const seconds = Math.floor((diff % 60000) / 1000).toString().padStart(2, '0');
        const countdown = `${minutes}:${seconds}`;

        DOMElements.rateLimitInfo.innerHTML = `
            <div>
                <p class="text-sm font-bold text-red-400">Limit Reached</p>
                <p class="text-xs text-gray-400">
                    Next generation available in: <span class="font-mono font-bold text-red-300">${countdown}</span>
                </p>
            </div>`;
    } else {
        DOMElements.rateLimitInfo.innerHTML = `
            <div>
                <p class="text-sm font-bold text-gray-300">Generations Remaining</p>
                <p class="text-2xl font-bold text-white">${state.rateLimitInfo.remaining} / ${state.rateLimitInfo.limit}</p>
                <p class="text-xs text-gray-500">Resets every 10 minutes</p>
            </div>`;
    }
}

function updateGenerateButtonState(state, DOMElements, isApiKeyMissing) {
    const isDisabled = !state.options.prompt.trim() || state.isLoading || isApiKeyMissing || (state.rateLimitInfo != null && (state.options.numberOfImages > state.rateLimitInfo.remaining));
    DOMElements.generateButton.disabled = isDisabled;
    DOMElements.generateButtonText.textContent = state.isLoading ? 'Generating...' : 'Generate';

    const allInputs = DOMElements.settingsPanel.querySelectorAll('input, button, select, textarea');
    allInputs.forEach(input => {
        if (input.id !== 'generate-button') {
            input.disabled = state.isLoading || isApiKeyMissing;
        }
    });
}

function updatePromptActionButtons(state, DOMElements, isApiKeyMissing) {
    DOMElements.improvePromptButton.disabled = !state.options.prompt.trim() || state.isPromptLoading || isApiKeyMissing;
    DOMElements.randomPromptButton.disabled = state.isPromptLoading || isApiKeyMissing;
    DOMElements.describeImageButton.disabled = !state.options.referenceImage || state.isPromptLoading || isApiKeyMissing;
}

export function renderAll(state, DOMElements, handlers, isApiKeyMissing) {
    renderSettings(state, DOMElements);
    renderImageGallery(state, DOMElements, handlers);
    renderHistory(state, DOMElements, handlers, isApiKeyMissing);
    renderSideMenu(state, DOMElements);
    renderRateLimit(state, DOMElements);
    updateGenerateButtonState(state, DOMElements, isApiKeyMissing);
    updatePromptActionButtons(state, DOMElements, isApiKeyMissing);
}
